# -*- coding: utf-8 -*-
import shutil
import time
import sqlite3 as database
from zipfile import ZipFile
from caches.settings_cache import set_setting
from modules.utils import string_alphanum_to_num, unzip
from modules import kodi_utils 
# logger = kodi_utils.logger

translate_path, osPath, delete_file, execute_builtin, get_icon = kodi_utils.translate_path, kodi_utils.osPath, kodi_utils.delete_file, kodi_utils.execute_builtin, kodi_utils.get_icon
update_kodi_addons_db, notification, show_text, confirm_dialog = kodi_utils.update_kodi_addons_db, kodi_utils.notification, kodi_utils.show_text, kodi_utils.confirm_dialog
requests, addon_info, confirm_dialog, ok_dialog = kodi_utils.requests, kodi_utils.addon_info, kodi_utils.confirm_dialog, kodi_utils.ok_dialog
update_local_addons, disable_enable_addon, close_all_dialog = kodi_utils.update_local_addons, kodi_utils.disable_enable_addon, kodi_utils.close_all_dialog
json, select_dialog, show_busy_dialog, hide_busy_dialog = kodi_utils.json, kodi_utils.select_dialog, kodi_utils.show_busy_dialog, kodi_utils.hide_busy_dialog

packages_dir = translate_path('special://home/addons/packages/')
home_addons_dir = translate_path('special://home/addons/')
destination_check = translate_path('special://home/addons/plugin.video.the_cow/')
changelog_location = translate_path('special://home/addons/plugin.video.the_cow/resources/text/changelog.txt')
downloads_icon = get_icon('downloads')
addon_dir = 'plugin.video.the_cow'
repo_location = 'elvis-gratton.github.io'
zipfile_name = 'plugin.video.the_cow-%s.zip'
versions_url = 'https://github.com/elvis-gratton/%s/raw/master/packages/the_cow_version'
changes_url = 'https://github.com/elvis-gratton/%s/raw/master/packages/the_cow_changes'
location_url = 'https://github.com/elvis-gratton/%s/raw/master/packages/%s'
contents_url = 'https://api.github.com/repos/elvis-gratton/%s/contents/packages'
heading_str = 'La Vache Updater'
error_str = 'Error'
notification_occuring_str = 'La Vache Update en Cours'
notification_available_str = 'La Vache Update Disponible'
notification_updating_str = 'La Vache Updating'
notification_rollback_str = 'La Vache Rollback Update'
result_str = 'Version Installee: [B]%s[/B][CR]Version en ligne: [B]%s[/B][CR][CR] %s'
no_update_str = '[B]Pas de Update Disponible[/B]'
update_available_str = '[B]Un Update est Disponible[/B][CR]Faire le  Update?'
success_str = '[CR]Succes.[CR]La Vache a Change pour la version [B]%s[/B]'
rollback_heading_str = 'Choisir une autre Version'
success_rollback_str = '[CR]Succes.[CR]La Vache rolled back a la version [B]%s[/B]'
confirm_rollback_str = 'Est-te vous certains?[CR]Version [B]%s[/B] vas overwriter la version installe.' \
						'[CR]La Vache vas passer le mode AutoUpdate a [B]OFF[/B] si le rollback est fait avec succes'
no_rollback_str = 'Aucune version Precedentetrouve.[CR]S.v.p. installer le rollback manuellement.'
error_update_str = 'Erreur pendant le Updating.[CR]S.v.p. installer le nouveau update manuellement'
error_rollback_str = 'Erreur pendant le rolling back.[CR]S.v.p. installer le rollback manuellement'
changes_heading_str = 'Nouvelle version en Ligne (v.%s) Changelog'
view_changes_str = 'Nouvelle version disponible [B](v.%s)[/B].[CR]Voulez vous voir les changelog avant l`installation?'
no_changes_str = 'Vous avez presentement la version a date de La Vache.[CR][CR]Aucune nouvelle version de changelog a voir.'

def get_versions():
	try:
		result = requests.get(versions_url % repo_location)
		if result.status_code != 200:
			return None, None
		online_version = result.text.replace('\n', '')
		current_version = addon_info('version')
		return current_version, online_version
	except:
		return None, None

def get_changes(online_version=None):
	try:
		if not online_version:
			current_version, online_version = get_versions()
			if not version_check(current_version, online_version): return ok_dialog(heading=heading_str, text=no_changes_str)
		show_busy_dialog()
		result = requests.get(changes_url % repo_location)
		hide_busy_dialog()
		if result.status_code != 200: return notification(error_str, icon=downloads_icon)
		changes = result.text
		return show_text(changes_heading_str % online_version, text=changes, font_size='large')
	except:
		hide_busy_dialog()
		return notification(error_str, icon=downloads_icon)

def version_check(current_version, online_version):
	return string_alphanum_to_num(current_version) != string_alphanum_to_num(online_version)

def update_check(action=4): # {'0': 'Demander avant', '1': 'Automatique', '2': 'Notification', '3': 'Off'}
	if action == 3:
		return
	current_version, online_version = get_versions()
	if not current_version:
		return
	if not version_check(current_version, online_version):
		if action == 4:
			return ok_dialog(heading=heading_str, text=result_str % (current_version, online_version, no_update_str))
		return
	if action in (0, 4):
		if confirm_dialog(heading=heading_str, text=view_changes_str % online_version, ok_label='Yes', cancel_label='No'):
			get_changes(online_version)
		if not confirm_dialog(heading=heading_str, text=result_str % (current_version, online_version, update_available_str), ok_label='Yes', cancel_label='No'):
			return
	if action == 1:
		notification(notification_occuring_str, icon=downloads_icon)
	elif action == 2:
		return notification(notification_available_str, icon=downloads_icon)
	return update_addon(online_version, action)

def rollback_check():
	current_version = get_versions()[0]

	url = contents_url % repo_location

	show_busy_dialog()
	results = requests.get(url)
	hide_busy_dialog()

	if results.status_code != 200:
		return ok_dialog(heading=heading_str, text=error_rollback_str)
	results = [i['name'].split('-')[1].replace('.zip', '') for i in results.json() if 'plugin.video.the_cow' in i['name'] \
				and not i['name'].split('-')[1].replace('.zip', '') == current_version]
	if not results:
		return ok_dialog(heading=heading_str, text=no_rollback_str)
	results.sort(reverse=True)

	list_items = [{'line1': item, 'icon': downloads_icon} for item in results]
	kwargs = {'items': json.dumps(list_items), 'heading': rollback_heading_str}
	rollback_version = select_dialog(results, **kwargs)

	if rollback_version == None:
		return
	if not confirm_dialog(heading=heading_str, text=confirm_rollback_str % rollback_version):
		return
	update_addon(rollback_version, 5)


def update_addon(new_version, action):
	close_all_dialog()
	execute_builtin('ActivateWindow(Home)', True)

	notification_str = notification_rollback_str if action == 5 else notification_updating_str
	notification(notification_str, icon=downloads_icon)

	# url link for addon zip
	zip_name = zipfile_name % new_version
	url = location_url % (repo_location, zip_name)

	# Download zip file
	show_busy_dialog()
	result = requests.get(url, stream=True)
	hide_busy_dialog()

	if result.status_code != 200:
		return ok_dialog(heading=heading_str, text=error_update_str)
	# copy file to folder special://home/addons/packages/
	zip_location = osPath.join(packages_dir, zip_name)
	with open(zip_location, 'wb') as f: shutil.copyfileobj(result.raw, f)
	# delete tree of the old addon
	shutil.rmtree(osPath.join(home_addons_dir, addon_dir))
	# unzip content of the zip to the folder addon ex: special://home/addons/plugin.video.the_cow/
	success = unzip(zip_location, home_addons_dir, destination_check)
	# delete addon zipfile in the folder special://home/addons/packages/
	delete_file(zip_location)
	if not success:
		return ok_dialog(heading=heading_str, text=error_update_str)
	if action == 5:
		set_setting('update.action', '3')
		ok_dialog(heading=heading_str, text=success_rollback_str % new_version)
	elif action in (0, 4) and confirm_dialog(heading=heading_str, text=success_str % new_version, ok_label='Changelog', cancel_label='Exit', default_control=10) != False:
			show_text('Changelog', file=changelog_location, font_size='large')

	update_local_addons()
	disable_enable_addon()
	update_kodi_addons_db()
