
import xbmc, xbmcvfs, xbmcgui
import json
from xbmcaddon import Addon

translatePath = xbmcvfs.translatePath
Window = xbmcgui.Window
window = Window(10000)
File, exists, copy, delete, rmdir, rename = xbmcvfs.File, xbmcvfs.exists, xbmcvfs.copy, xbmcvfs.delete, xbmcvfs.rmdir, xbmcvfs.rename
listdir, mkdir, mkdirs = xbmcvfs.listdir, xbmcvfs.mkdir, xbmcvfs.mkdirs

the_cow_settings_str = 'the_cow_settings'
suppress_sett_dict_prop = 'the_cow.suppress_settings_dict'

userdata_path = translatePath('special://profile/addon_data/plugin.video.the_cow/')
user_settings = translatePath('special://profile/addon_data/plugin.video.the_cow/settings.xml')


def get_property(prop):
	return window.getProperty(prop)

def set_property(prop, value):
	return window.setProperty(prop, value)

def clear_property(prop):
	return window.clearProperty(prop)

def addon(addon_id='plugin.video.the_cow'):
    return Addon(id=addon_id)

def path_exists(path):
    return exists(path)

def make_directory(path):
    mkdir(path)

def make_directories(path):
    mkdirs(path)

def delete_settings_xml():
	return delete(user_settings)


########################################################################
def rd_enabled():
    return get_setting('rd.enabled', 'false') == 'true'

def rd_client_id():
    return get_setting('rd.client_id', 'empty_setting')

def rd_refresh():
    return get_setting('rd.refresh', 'empty_setting')

def rd_secret():
    return get_setting('rd.secret', 'empty_setting')

def rd_token():
    return get_setting('rd.token', 'empty_setting')

def rd_account_id():
    return get_setting('rd.account_id', 'empty_setting')
########################################################################


def set_setting(setting_id, value):
    addon().setSetting(setting_id, value)

def get_setting(setting_id, fallback=None):
	if get_property(suppress_sett_dict_prop): return addon().getSetting(setting_id)
	try: settings_dict = json.loads(get_property(the_cow_settings_str))
	except: settings_dict = make_settings_dict()
	if settings_dict is None or setting_id not in settings_dict:
		settings_dict = get_setting_fallback(setting_id)
		if not get_property(suppress_sett_dict_prop) == 'true':
			make_settings_dict()
	value = settings_dict.get(setting_id, '')
	if value == '':
		if fallback is None: return value
		return fallback
	return value

def get_setting_fallback(setting_id):
	return {setting_id: addon().getSetting(setting_id)}

def make_settings_dict():
	settings_dict = None
	clear_property(the_cow_settings_str)
	if not get_property(suppress_sett_dict_prop) == 'true':
		from xml.dom.minidom import parse as mdParse
		try:
			if not path_exists(userdata_path): make_directories(userdata_path)
			settings_dict = {}
			dict_update = settings_dict.update
			for item in mdParse(user_settings).getElementsByTagName('setting'):
				setting_id = item.getAttribute('id')
				try: setting_value = item.firstChild.data
				except: setting_value = None
				if setting_value is None: setting_value = ''
				dict_item = {setting_id: setting_value}
				dict_update(dict_item)
			set_property(the_cow_settings_str, json.dumps(settings_dict))
		except Exception as e:
			settings_dict = None
			set_property(suppress_sett_dict_prop, 'true')
	return settings_dict
