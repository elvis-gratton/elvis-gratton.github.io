# -*- coding: UTF-8 -*-
# Jackett indexer
import json
import re
import time
from urllib.parse import quote
from the_milk.modules import client
from the_milk.modules import source_utils
from the_milk.modules import workers
from the_milk.modules import log_utils
from the_milk.modules import control
from the_milk.modules.cleantitle import normalize
from the_milk.modules.source_utils import convert_size


# note: modules.client need modification for Magnet (url forward 302 to magnet link)

# ApiTracker = '&Tracker[]=torrent9,torrent911,yggtorrent'
# s = 'apikey=%s&Query=%s&Category[]=%s' % (Apikey, ApiQuery, ApiCategory) + ApiTracker
# url_search = Api_domain + Api_search + quote(s, safe='/&=')

#### INFO SUR LE TRACKER
# les recherches utilisent le titre original
# example:
# original en-US anglais = the matrix
# titre fr-FR francais = matrix
# la recherche est faite avec  en-US ici

class jackett_row:
    tracker: str
    title: str
    quality: str
    info: str
    category: str
    size: int
    seeds: int
    link: str

    def __init__(self, tracker: str, title: str, category: str, size: int, seeds: int, link: str):
        self.tracker = tracker
        self.title = title
        self.quality, self.info = source_utils.get_release_quality(title, None)
        self.category = category
        self.size = size
        self.seeds = seeds
        self.link = link


class jackett_indexers:
    def __init__(self):
        self.rows = []

    def process(self, j_resp: str):
        if j_resp is None:
            return []

        try:
            j = json.loads(j_resp)
        except Exception as e:
            log_utils.log('jackett_indexers Json.loads %s' % str(e))
            return []

        try:
            for r in j['Results']:
                jr = jackett_row(r['TrackerId'], r['Title'], r['CategoryDesc'], r['Size'], r['Seeders'], r['Link'])
                self.rows.append(jr)
        except Exception as e:
            log_utils.log('jackett_indexers for r in ["Results"] %s' % str(e))
            return []

        return self.rows


class source:
    name = 'oxtorrents'
    language = ['fr']
    priority = 5
    pack_capable = True
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.ReqSearchTimeout = 60  # Cloudflare init response delay
        self.ReqTimeout = 5
        self.request_delay = 1  # 1s

        apikey = control.setting('jackett.apikey')
        apidomain = control.setting('jackett.domain')
        if not apidomain.startswith('http'):
            apidomain = 'https://' + apidomain

        apiendpoint = '/api/v2.0/indexers/oxtorrent/results?'
        self.ApiCategoryMovies = '&Category[]=2000,8000'
        self.ApiCategoryTv = '&Category[]=5000,8000'
        self.ApiCategoryOthers = '&Category[]=8000'
        self.ApiBaseLink = apidomain + apiendpoint + 'apikey=%s' % apikey
        self.MaxPerSearch = int(control.setting('jackett.maxpersearch'))
        self.min_seeders = 0
        self.debug = False
        self._debug_it('Init')

    def _debug_it(self, msg, caller=None):
        if self.debug:
            log_utils.log('oxtorrents. %s' % msg, caller, 1)

    def test(self):
        self._debug_it('test button call')

    def sources(self, data, host_dict):
        """
        :param data:
        :param host_dict:
        :return:
        """
        self.sources = []
        if not data:
            self._debug_it('sources: data empty')
            return self.sources

        self.sources_append = self.sources.append
        try:
            self.aliases = data['aliases']
            self.original_title = data['original_title'].lower().replace('/', '-').replace('$', 's').replace('!', '').replace('\'', '')
            self.original_title = normalize(self.original_title)


            if 'tvshowtitle' in data:
                l_title = data['tvshowtitle'].lower().replace('/', '-').replace('$', 's').replace('!', '').replace('\'', '')
                self.title = normalize(l_title)
                self.episode_title = data['title'].lower()
                self.is_movie = False
                self.year = ''
                self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
                season = data['season']
                episode = data['episode']
                self.years = None
            else:
                l_title = data['title'].lower().replace('/', '-').replace('$', 's').replace('!', '').replace('\'', '')
                self.title = normalize(l_title)
                self.episode_title = None
                self.is_movie = True
                self.year = data['year']
                self.hdlr = self.year
                season = None
                episode = None
                try:
                    self.years = [str(int(self.year) - 1), self.year, str(int(self.year) + 1)]
                except:
                    self.years = None

            self._debug_it('sources: original_title = %s' % self.original_title)
            self._debug_it('sources: title          = %s' % self.title)
            self._debug_it('sources: aliases        = %s' % self.aliases)
            self._debug_it('sources: year           = %s' % self.year)
            self._debug_it('sources: season         = %s' % season)
            self._debug_it('sources: episode        = %s' % episode)

            links = []
            if self.is_movie:
                link = self.ApiBaseLink + quote(self.ApiCategoryMovies + '&query=' + self.title, safe='/&=')
                links.append(link)  # without year

                if self.title != self.original_title:
                    link = self.ApiBaseLink + quote(self.ApiCategoryMovies + '&query=' + self.original_title, safe='/&=')
                    links.append(link)  # without year
            else:
                #title_no_sxxexx = re.sub('s\d\de\d\d', '', self.original_title)
                #link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + title_no_sxxexx, safe='/&=')
                link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + self.title + ' ' + self.hdlr,safe='/&=')
                links.append(link)  # without year
                if self.title != self.original_title:
                    link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + self.original_title + ' ' + self.hdlr, safe='/&=')
                    links.append(link)  # without year


            self._debug_it('sources: links=%s' % links)

            self.undesirables = source_utils.get_undesirables()
            threads = []
            append = threads.append

            for link in links:
                append(workers.Thread(self.get_sources, link))

            [i.start() for i in threads]
            [i.join() for i in threads]
            return self.sources
        except Exception as e:
            self._debug_it('sources: %s' % str(e))
            return self.sources

    def get_sources(self, link):
        """
        :param link:
        :return:
        """
        # https Request 1. Search Page
        self._debug_it('get_sources: link search START %s' % link)
        try:
            results = client.request(link, timeout=self.ReqSearchTimeout)
        except Exception as e:
            self._debug_it('get_sources: Exception https request search item %s' % str(e))
            return None
        self._debug_it('get_sources: link search END   %s' % link)

        if results is None:
            self._debug_it('get_sources: results is None')
            return None

        ji = jackett_indexers()
        rows = ji.process(results)
        if len(rows) == 0:
            return None

        self._debug_it('get_sources: tr parsing done rows=%s' % len(rows))
        self._debug_it('-')

        for x, row in enumerate(rows, 1):

            filename = normalize(
                row.title.lower().replace('version longue', '').replace('extended', '').replace('complete', '').replace(
                    'integrale', '').replace('remastered', ''))
            if 'vostfr' in filename or 'vost.en-fr' in filename or 'subfrench' in filename:
                continue

            name_info = source_utils.info_from_name(filename, self.title, self.year, self.hdlr, self.episode_title)
            row.quality, row.info = source_utils.get_release_quality(name_info, None)

            t = re.split('french|truefrench|multi |vff|vfq|vfi|vf2', filename, 1)
            if not t or len(t) < 2:
                self._debug_it('get_sources: French not detected')
                continue

            year_str = re.findall("19\d\d|20\d\d", t[1])
            if year_str:
                file_title = str(t[0]) + str(year_str[0])
            else:
                year_str2 = re.findall("19\d\d|20\d\d", t[0])
                if year_str2:
                    file_title = str(t[0]) + str(year_str2[0])
                else:
                    file_title = str(t[0])

            file_title = re.sub('\((.*?)\)', '', file_title)

            if not self.is_movie:
                tmp_filename = re.sub(".19\d\d|.20\d\d", '', file_title)
            else:
                tmp_filename = file_title

            if not source_utils.check_title(self.title, self.aliases, tmp_filename, self.hdlr, self.year, self.years):
                if not source_utils.check_title(self.original_title, self.aliases, tmp_filename, self.hdlr, self.year,self.years):
                    self._debug_it('get_sources: check_title FAILED!  T=%s OT=%s FN=%s H=%s Y=%s YS=%s' % (
                    self.title, self.original_title, tmp_filename, self.hdlr, self.year, self.years))
                    continue

            self._debug_it(
                'get_sources: check_title OK!  T=%s FT=%s Y=%s A=%s' % (self.title, tmp_filename, self.year, self.aliases))

            # Maximum request for details page(Hash) on success search  titles
            #if x > self.MaxPerSearch:
            #    break

            ### https Request 2. Page Infos ###

            self._debug_it('get_sources: get Magnet START')
            try:
                magnet_link = client.request(row.link, timeout=self.ReqTimeout)
            except Exception as e:
                self._debug_it('get_sources: Exception https request magnet %s' % str(e))
                continue

            self._debug_it('get_sources:1 tracker=%s  title=%s  link=%s' % (row.tracker, row.title, row.link))
            self._debug_it('get_sources:2 tracker=%s  title=%s  magnet=%s' % (row.tracker, row.title, magnet_link))

            self._debug_it('get_sources: get Magnet END')

            time.sleep(self.request_delay)

            if not magnet_link or not magnet_link.startswith('magnet'):
                continue

            seeders = row.seeds
            quality = row.quality
            info = row.info

            if row.size > 1073741824:
                dsize, isize = convert_size(row.size, 'GB')
            elif row.size > 1048576:
                dsize, isize = convert_size(row.size, 'MB')
            elif row.size > 1024:
                dsize, isize = convert_size(row.size, 'KB')
            else:
                dsize, isize = 0, '0'

            try:
                hash40 = re.findall('magnet:\?xt=urn:btih:(.*?)&', magnet_link)[0]
            except:
                continue

            if len(hash40) == 32:
                try:
                    hash40 = source_utils.base32_to_hex(hash40, 'get_sources')
                except Exception as e:
                    self._debug_it('get_sources: base32_to_hex %s' % str(e))
                    continue

            self.sources_append(
                {'provider': 'oxtorrents', 'source': 'torrent', 'seeders': seeders, 'hash': hash40, 'name': filename,
                 'name_info': name_info, 'quality': quality, 'language': 'fr', 'url': magnet_link, 'info': info,
                 'direct': False,
                 'debridonly': True, 'size': dsize})

            self._debug_it('APPEND Provider= %s' % row.tracker)
            self._debug_it('APPEND filename= %s' % filename)
            self._debug_it('APPEND quality= %s size= %s' % (quality, isize))
            self._debug_it('APPEND magnet= %s' % magnet_link)
            self._debug_it(
                'APPEND seeders= %s hash= %s filename= %s nameInfo= %s quality= %s size=%s url= %s' % (
                    seeders, hash40, filename, name_info, quality, isize, magnet_link))
            self._debug_it('-')

    def sources_packs(self, data, host_dict, search_series=False, total_seasons=None, bypass_filter=False):
        """
        :param data:
        :param host_dict:
        :param search_series:
        :param total_seasons:
        :param bypass_filter:
        :return:
        """
        self.sources = []
        if not data:
            self._debug_it('sources_packs: data empty')
            return self.sources

        self._debug_it('sources_packs')
        self.sources_append = self.sources.append
        self.original_title = data['original_title'].lower().replace('/', ' ').replace('$', 's').replace('!', '').replace('\'', '')
        self.original_title = normalize(self.original_title)

        try:
            self.search_series = search_series
            self.total_seasons = total_seasons
            self.bypass_filter = bypass_filter

            l_title = data['tvshowtitle'].lower().replace('/', ' ').replace('$', 's').replace('!', '').replace('\'', '')
            self.title = normalize(l_title)

            self.aliases = data['aliases']
            self.imdb = data['imdb']
            self.year = data['year']
            self.season_x = data['season']
            self.season_xx = self.season_x.zfill(2)
            self.undesirables = source_utils.get_undesirables()
            self.check_foreign_audio = source_utils.check_foreign_audio()

            self._debug_it('sources_packs: original_title = %s' % self.original_title)
            self._debug_it('sources_packs: title          = %s' % self.title)
            self._debug_it('sources_packs: aliases        = %s' % self.aliases)
            self._debug_it('sources_packs: year           = %s' % self.year)
            self._debug_it('sources_packs: season_x       = %s' % self.season_x)
            self._debug_it('sources_packs: season_xx      = %s' % self.season_xx)


            links = []

            #link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + self.title + ' integrale', safe='/&=')
            #link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + self.original_title + ' integrale', safe='/&=')
            #links.append(link)

            tmp_title = self.title + ' saison'
            link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + tmp_title, safe='/&=')
            links.append(link)
            self._debug_it('sources_packs: title=%s  link= %s' % (tmp_title, link))

            tmp_title = self.title + ' S' + self.season_xx
            link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + tmp_title, safe='/&=')
            links.append(link)
            self._debug_it('sources_packs: title=%s  link= %s' % (tmp_title, link))

            tmp_title = self.title + ' integral'
            link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + tmp_title, safe='/&=')
            links.append(link)
            self._debug_it('sources_packs: title=%s  link= %s' % (tmp_title, link))

            if self.title != self.original_title:
                tmp_title = self.original_title + ' saison'
                link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + tmp_title, safe='/&=')
                links.append(link)
                self._debug_it('sources_packs: original_title=%s  link= %s' % (tmp_title, link))

                tmp_title = self.original_title + ' S' + self.season_xx
                link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + tmp_title, safe='/&=')
                links.append(link)
                self._debug_it('sources_packs: original_title=%s  link= %s' % (tmp_title, link))

                tmp_title = self.original_title + ' integral'
                link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + tmp_title, safe='/&=')
                links.append(link)
                self._debug_it('sources_packs: original_title=%s  link= %s' % (tmp_title, link))



            tmp = self.original_title.split(':', 1)
            if len(tmp) > 0:
                tmp = tmp[0]
            else:
                tmp = self.original_title

            link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + tmp + ' integrale', safe='/&=')
            links.append(link)
            self._debug_it('sources_packs: title=%s  link= %s' % (self.original_title, link))

            link = self.ApiBaseLink + quote(self.ApiCategoryTv + '&query=' + self.original_title + ' S' + self.season_xx,
                                            safe='/&=')
            links.append(link)
            self._debug_it('sources_packs: title=%s  link= %s' % (self.original_title, link))

            threads = []
            append = threads.append

            for link in links:
                append(workers.Thread(self.get_sources_packs, link))
                time.sleep(self.request_delay)

            [i.start() for i in threads]
            [i.join() for i in threads]
            return self.sources

        except Exception as e:
            self._debug_it('sources_packs: Exception %s' % str(e))
            return self.sources

    def get_sources_packs(self, link):
        """
        :param link:
        :return:
        """
        ### https Request 1. Search Page ###
        try:
            results = client.request(link, timeout=self.ReqSearchTimeout)
        except Exception as e:
            self._debug_it('get_sources_packs: Exception https request search item %s' % str(e))
            return None

        if results is None:
            self._debug_it('get_sources_packs: results is None')
            return None

        ji = jackett_indexers()
        rows = ji.process(results)
        if len(rows) == 0:
            return None

        self._debug_it('get_sources_packs: tr parsing done rows=%s' % len(rows))
        self._debug_it('-')

        for row in rows:
            filename = normalize(row.title.replace('version longue', '').replace('extended', ''))

            if 'vostfr' in filename or 'vost.en-fr' in filename or 'subfrench' in filename:
                continue

            t = re.split('french|truefrench|multi |vff|vfq', filename, 1)
            if not t or len(t) < 2:
                self._debug_it('get_sources_packs: French not detected')
                continue

            year_str = re.findall("19\d\d|20\d\d", t[1])
            if year_str:
                tmp_filename = str(t[0]) + str(year_str[0])
            else:
                tmp_filename = str(t[0])

            tmp_filename = re.sub("\(([^\)]+)\)", "", tmp_filename)
            # tmp_filename = re.sub("19\d\d|20\d\d", '', tmp_filename)
            self._debug_it('get_sources_packs: T=%s Original_title=%s ' % (self.title, self.original_title))
            self._debug_it('get_sources_packs: filename=%s' % filename)
            self._debug_it('get_sources_packs: Clean filename=%s' % tmp_filename)
            self._debug_it('get_sources_packs: aliases=%s' % self.aliases)

            episode_start, episode_end, valid = 0, 0, False
            if not self.search_series:
                if not self.bypass_filter:
                    valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases,
                                                                                        self.year, self.season_x,
                                                                                        tmp_filename)
                    self._debug_it('get_sources_packs:1. filter season valid=%s' % str(valid))
                    if not valid:
                        valid, episode_start, episode_end = source_utils.filter_season_pack(self.original_title,
                                                                                            self.aliases, self.year,
                                                                                            self.season_x, tmp_filename)
                        self._debug_it('get_sources_packs:2. filter season valid=%s' % str(valid))
                        if not valid:
                            continue
                package = 'season'

            elif self.search_series:
                if not self.bypass_filter:
                    valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year,
                                                                       self.season_x, tmp_filename, self.total_seasons)
                    self._debug_it('get_sources_packs:1 filter show valid=%s' % str(valid))
                    if not valid:
                        valid, last_season = source_utils.filter_show_pack(self.original_title, self.aliases, self.imdb,
                                                                           self.year, self.season_x, tmp_filename,
                                                                           self.total_seasons)
                        self._debug_it('get_sources_packs:2 filter show valid=%s' % str(valid))
                        if not valid:
                            continue
                else:
                    last_season = self.total_seasons
                package = 'show'

            self._debug_it('get_sources_packs: filter result OK!  T=%s OT=%s FN=%s Y=%s A=%s' % (
            self.title, self.original_title, filename, self.year, self.aliases))

            ### https Request 2. Page Infos ###

            try:
                magnet_link = client.request(row.link, timeout=self.ReqTimeout)
            except Exception as e:
                self._debug_it('get_sources_packs: Exception https request magnet_link %s' % str(e))
                continue

            time.sleep(self.request_delay)

            if not magnet_link or not magnet_link.startswith('magnet'):
                continue

            name_info = source_utils.info_from_name(filename, self.title, self.year, season=self.season_x, pack=package)
            row.quality, row.info = source_utils.get_release_quality(name_info, None)

            seeders = row.seeds
            quality = row.quality
            info = row.info

            if row.size > 1073741824:
                dsize, isize = convert_size(row.size, 'GB')
            elif row.size > 1048576:
                dsize, isize = convert_size(row.size, 'MB')
            elif row.size > 1024:
                dsize, isize = convert_size(row.size, 'KB')
            else:
                dsize, isize = 0, '0'

            try:
                hash40 = re.findall('magnet:\?xt=urn:btih:(.*?)&', magnet_link)[0]
            except:
                continue

            if len(hash40) == 32:
                try:
                    hash40 = source_utils.base32_to_hex(hash40, 'get_sources_packs')
                except Exception as e:
                    self._debug_it('get_sources_packs: base32_to_hex %s' % str(e))
                    continue

            self._debug_it('get_sources_packs: parsing done')

            item = {'provider': 'oxtorrents', 'source': 'torrent', 'seeders': seeders, 'hash': hash40, 'name': filename,
                    'name_info': name_info, 'quality': quality,
                    'language': 'fr', 'url': magnet_link, 'info': info, 'direct': False, 'debridonly': True,
                    'size': dsize,
                    'package': package}

            self._debug_it('APPEND PACKS Provider= %s' % row.tracker)
            self._debug_it('APPEND PACKS filename= %s' % filename)
            self._debug_it('APPEND PACKS quality= %s size= %s' % (quality, isize))
            self._debug_it('APPEND PACKS magnet= %s' % magnet_link)
            self._debug_it(
                'APPEND PACKS seeders= %s hash= %s filename= %s nameInfo= %s quality= %s size= %s url= %s' % (
                    seeders, hash40, filename, name_info, quality, isize, magnet_link))
            self._debug_it('-')

            if self.search_series:
                item.update({'last_season': last_season})

            elif episode_start:
                item.update({'episode_start': episode_start, 'episode_end': episode_end})  # for partial season packs

            self.sources_append(item)

    def main(self):
        from the_milk.modules.test_modules import Tests
        tests = Tests()
        self.sources(tests.data_movie_4(), '')


if __name__ == "__main__":
    jj = source()
    jj.main()

