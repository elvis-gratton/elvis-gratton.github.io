# YApi QuickType插件生成，具体参考文档:https://plugins.jetbrains.com/plugin/18847-yapi-quicktype/documentation

from enum import Enum
from datetime import datetime
from typing import List, Any, Optional


class ID(Enum):
    gktorrent = "gktorrent"
    torrent9 = "torrent9"
    torrent911 = "torrent911"
    yggtorrent = "yggtorrent"
    zetorrents = "zetorrents"


class Name(Enum):
    GkTorrent = "GkTorrent"
    Torrent9 = "Torrent9"
    Torrent911 = "Torrent911"
    YGGtorrent = "YGGtorrent"
    zetorrents = "zetorrents"


class Indexer:
    Status: int
    Results: int
    ID: ID
    Name: Name

    def __init__(self, Status: int, Results: int, ID: ID, Name: Name) -> None:
        self.Status = Status
        self.Results = Results
        self.ID = ID
        self.Name = Name


class CategoryDesc(Enum):
    Movies = "Movies"
    MoviesOther = "Movies/Other"
    Other = "Other"
    TV = "TV"
    TVDocumentary = "TV/Documentary"


class TrackerType(Enum):
    public = "public"
    semiprivate = "semi-private"


class Result:
    Tracker: Name
    PublishDate: datetime
    Category: List[int]
    Size: int
    DownloadVolumeFactor: int
    Seeders: int
    Languages: List[Any]
    Guid: str
    Genres: List[Any]
    CategoryDesc: CategoryDesc
    Peers: int
    UploadVolumeFactor: int
    TrackerId: ID
    Title: str
    Details: str
    FirstSeen: datetime
    Subs: List[Any]
    TrackerType: TrackerType
    Link: str
    Gain: float
    Grabs: Optional[int]

    def __init__(self, Tracker: Name, PublishDate: datetime, Category: List[int], Size: int, DownloadVolumeFactor: int, Seeders: int, Languages: List[Any], Guid: str, Genres: List[Any], CategoryDesc: CategoryDesc, Peers: int, UploadVolumeFactor: int, TrackerId: ID, Title: str, Details: str, FirstSeen: datetime, Subs: List[Any], TrackerType: TrackerType, Link: str, Gain: float, Grabs: Optional[int]) -> None:
        self.Tracker = Tracker
        self.PublishDate = PublishDate
        self.Category = Category
        self.Size = Size
        self.DownloadVolumeFactor = DownloadVolumeFactor
        self.Seeders = Seeders
        self.Languages = Languages
        self.Guid = Guid
        self.Genres = Genres
        self.CategoryDesc = CategoryDesc
        self.Peers = Peers
        self.UploadVolumeFactor = UploadVolumeFactor
        self.TrackerId = TrackerId
        self.Title = Title
        self.Details = Details
        self.FirstSeen = FirstSeen
        self.Subs = Subs
        self.TrackerType = TrackerType
        self.Link = Link
        self.Gain = Gain
        self.Grabs = Grabs


class JackettResponse:
    Results: List[Result]
    Indexers: List[Indexer]

    def __init__(self, Results: List[Result], Indexers: List[Indexer]) -> None:
        self.Results = Results
        self.Indexers = Indexers
