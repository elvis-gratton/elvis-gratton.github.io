# -*- coding: UTF-8 -*-
# Jackett indexer
import json
import re
import time
from enum import Enum
from urllib.parse import quote
from the_milk.modules import client
from the_milk.modules import source_utils
from the_milk.modules import workers
from the_milk.modules import log_utils
from the_milk.modules import control
from the_milk.modules.cleantitle import normalize
from the_milk.modules.source_utils import convert_size


class sw_cats(Enum):
    ALL = ''
    film = '&Category[]=100009'
    serie = '&Category[]=100010'

class jackett_row:
    tracker: str
    title: str
    category: str
    size: int
    seeds: int
    link: str
    infoHash: str
    magnetUri: str
    details: str
    imdb_id: str
    languages: str
    year: int
    info: str
    quality: str

    def __init__(self, tracker: str, title: str, category: str, size: int, seeds: int, link: str, infohash: str, magneturi: str, details: str, imdbid: int, languages: str, year: int):
        self.tracker = tracker
        self.title = title
        self.category = category
        self.size = size
        self.seeds = seeds
        self.link = link
        self.infoHash = infohash
        self.magnetUri = magneturi
        self.details = details
        if imdbid:
            self.imdb_id = 'tt%s' % str(imdbid)
        else:
            self.imdb_id = ''
        self.languages = languages
        self.year = year
        self.quality, self.info = source_utils.get_release_quality(title, None)

class jackett_indexers:
    def __init__(self):
        self.rows = []

    def process(self, j_resp: str):
        if j_resp is None:
            return []

        try:
            j = json.loads(j_resp)
        except Exception as e:
            log_utils.log('jackett_indexers Json.loads %s' % str(e))
            return []

        try:
            for r in j['Results']:
                log_utils.log('jackett_indexers row = %s' % r)
                jr = jackett_row(r['TrackerId'], r['Title'], r['CategoryDesc'], r['Size'], r['Seeders'], r['Link'], r['InfoHash'], r['MagnetUri'], r['Details'], r['Imdb'], r['Languages'], r['Year'])
                self.rows.append(jr)
        except Exception as e:
            log_utils.log('jackett_indexers for r in ["Results"] %s' % str(e))
            return []

        return self.rows


class source:
    name = 'zileanapi'
    language = ['fr']
    priority = 1
    pack_capable = True
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.ReqSearchTimeout = 60  # Cloudflare init response delay
        self.ReqTimeout = 5
        self.request_delay = 2  # 2s
        apikey = control.setting('jackett.apikey')
        apidomain = control.setting('jackett.domain')
        if not apidomain.startswith('http'):
            apidomain = 'https://' + apidomain

        apiendpoint = '/api/v2.0/indexers/%s/results?' % source.name
        self.ApiBaseLink = apidomain + apiendpoint + 'apikey=%s' % apikey
        self.MaxPerSearch = int(control.setting('jackett.maxpersearch'))
        self.min_seeders = 0
        self.debug = True
        self._debug_it('Init')

    def _debug_it(self, msg, caller=None):
        if self.debug:
            log_utils.log('%s. %s' % (source.name, msg), caller, 1)

    def test(self):
        self._debug_it('test button call')

    def sources(self, data, host_dict):
        """
        :param data:
        :param host_dict:
        :return:
        """
        self.sources = []
        if not data:
            self._debug_it('sources: data empty')
            return self.sources

        self.sources_append = self.sources.append
        try:
            self._debug_it('sources: data original_title = %s' % data['original_title'])

            if 'tvshowtitle' in data:
                self._debug_it('sources: data tvshowtitle= %s' % data['tvshowtitle'])
            else:
                self._debug_it('sources: data title          = %s' % data['title'])

            self._debug_it('sources: data imdb           = %s' % data['imdb'])

            self.aliases = data['aliases']
            self.original_title = normalize(data['original_title'].lower().replace('/', '-').replace('$', 's').replace('!', '').replace(':', ' '))
            ApiCat = ''

            if 'tvshowtitle' in data:
                l_title = data['tvshowtitle'].lower().replace('/', '-').replace('$', 's').replace('!', '').replace(':', ' ')
                self.title = normalize(l_title)
                self.episode_title = data['title'].lower()
                self.is_movie = False
                self.year = ''
                self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
                self.years = None
                ApiCat = sw_cats.serie.value
            else:
                l_title = data['title'].lower().replace('/', '-').replace('$', 's').replace('!', '').replace(':', ' ')
                self.title = normalize(l_title)
                self.episode_title = None
                self.is_movie = True
                self.year = data['year']
                self.hdlr = self.year
                season = None
                episode = None
                ApiCat = sw_cats.film.value

                try:
                    self.years = [str(int(self.year) - 1), self.year, str(int(self.year) + 1)]
                except:
                    self.years = None

            self._debug_it('sources: original_title = %s' % self.original_title)
            self._debug_it('sources: title          = %s' % self.title)
            self._debug_it('sources: aliases        = %s' % self.aliases)
            self._debug_it('sources: year           = %s' % self.year)
            self._debug_it('sources: hdlr           = %s' % self.hdlr)


            links = []
            if self.is_movie:
                link = self.ApiBaseLink + quote(ApiCat + '&query=' + self.original_title, safe='/&=')
                links.append(link)  # without year
            else:                       # &category[10]&query='westworld' + ' ' + 'S01E01'
                link = self.ApiBaseLink + quote(ApiCat + '&query=' + self.original_title + ' ' + self.hdlr, safe='/&=')
                links.append(link)  # without year


            self._debug_it('sources: links=%s' % links)

            self.undesirables = source_utils.get_undesirables()
            threads = []
            append = threads.append

            for link in links:
                append(workers.Thread(self.get_sources, link))
                time.sleep(self.request_delay)

            [i.start() for i in threads]
            [i.join() for i in threads]
            return self.sources
        except Exception as e:
            self._debug_it('sources: %s' % str(e))
            return self.sources

    def get_sources(self, link):
        """
        :param link:
        :return:
        """
        # https Request 1. Search Page
        self._debug_it('get_sources: link search %s' % link)
        try:
            results = client.request(link, timeout=self.ReqSearchTimeout)
        except Exception as e:
            self._debug_it('get_sources: Exception https request search item %s' % str(e))
            return None

        if results is None:
            self._debug_it('get_sources: results is None')
            return None

        ji = jackett_indexers()
        rows = ji.process(results)
        if len(rows) == 0:
            self._debug_it('get_sources: No Rows')
            return None

        self._debug_it('get_sources: tr parsing done rows=%s' % len(rows))
        self._debug_it('-')

        for x, row in enumerate(rows, 1):

            filename = normalize(row.title.replace('version longue', '').replace('extended', '').replace('complete', '').replace('integrale', '').replace(':', ''))
            if 'vostfr' in filename or 'vost.en-fr' in filename or 'subfrench' in filename:
                continue

            name_info = source_utils.info_from_name(filename, self.title, self.year, self.hdlr, self.episode_title)
            row.quality, row.info = source_utils.get_release_quality(name_info, None)


            t = re.split('french|truefrench|multi |vff|vfq|vfi|fre', filename, 1)
            if not t or len(t) < 2:
                self._debug_it('get_sources: French not detected! FN= %s' % filename)
                continue

            year_str = re.findall("19\d\d|20\d\d", t[1])
            if year_str:
                file_title = str(t[0]) + str(year_str[0])
            else:
                file_title = str(t[0])

            file_title = re.sub('\((.*?)\)', '', file_title)

            if not self.is_movie:
                tmp_filename = re.sub(".19\d\d|.20\d\d", '', file_title)
            else:
                tmp_filename = file_title

            if not source_utils.check_title(self.title, self.aliases, tmp_filename, self.hdlr, self.year, self.years):
                if not source_utils.check_title(self.original_title, self.aliases, tmp_filename, self.hdlr, self.year,self.years):
                    self._debug_it('get_sources: check_title FAILED!  T=%s OT=%s FN=%s H=%s Y=%s YS=%s' % (
                    self.title, self.original_title, tmp_filename, self.hdlr, self.year, self.years))
                    continue

            self._debug_it(
                'get_sources: check_title OK!  T=%s FT=%s Y=%s A=%s' % (self.title, tmp_filename, self.year, self.aliases))

            # Maximum request for details page(Hash) on success search  titles
            #if x > self.MaxPerSearch:
            #    break

            if not row.magnetUri or 'magnet' not in row.magnetUri:
                continue

            hash40 = row.infoHash

            seeders = row.seeds
            quality = row.quality
            info = row.info

            if row.size > 1073741824:
                dsize, isize = convert_size(row.size, 'GB')
            elif row.size > 1048576:
                dsize, isize = convert_size(row.size, 'MB')
            elif row.size > 1024:
                dsize, isize = convert_size(row.size, 'KB')
            else:
                dsize, isize = 0, '0'

            if len(hash40) == 32:
                try:
                    hash40 = source_utils.base32_to_hex(hash40, 'get_sources')
                except Exception as e:
                    self._debug_it('get_sources: base32_to_hex %s' % str(e))
                    continue

            self.sources_append(
                {'provider': source.name, 'source': 'torrent', 'seeders': seeders, 'hash': hash40, 'name': filename,
                 'name_info': name_info, 'quality': quality, 'language': 'fr', 'url': row.magnetUri, 'info': info,
                 'direct': False,
                 'debridonly': True, 'size': dsize})

            self._debug_it('APPEND Provider= %s' % row.tracker)
            self._debug_it('APPEND filename= %s' % filename)
            self._debug_it('APPEND quality= %s size= %s' % (quality, isize))
            self._debug_it('APPEND magnet= %s' % row.magnetUri)
            self._debug_it('-')

    def sources_packs(self, data, host_dict, search_series=False, total_seasons=None, bypass_filter=False):
        """
        :param data:
        :param host_dict:
        :param search_series:
        :param total_seasons:
        :param bypass_filter:
        :return:
        """
        self.sources = []
        if not data:
            self._debug_it('sources_packs: data empty')
            return self.sources

        self._debug_it('sources_packs')
        self.sources_append = self.sources.append
        ApiCat = ''
        self.original_title = data['original_title'].lower().replace('/', ' ').replace('$', 's').replace('!', '').replace(':', ' ')
        self.original_title = normalize(self.original_title)

        try:
            self.search_series = search_series
            self.total_seasons = total_seasons
            self.bypass_filter = bypass_filter
            ApiCat = sw_cats.serie.value

            l_title = data['tvshowtitle'].lower().replace('/', ' ').replace('$', 's').replace('!', '').replace(':', ' ')
            self.title = normalize(l_title)

            self.aliases = data['aliases']
            self.imdb = data['imdb']
            self.year = data['year']
            self.season_x = data['season']
            self.season_xx = self.season_x.zfill(2)
            self.undesirables = source_utils.get_undesirables()
            self.check_foreign_audio = source_utils.check_foreign_audio()

            self._debug_it('sources_packs: original_title = %s' % self.original_title)
            self._debug_it('sources_packs: title          = %s' % self.title)
            self._debug_it('sources_packs: aliases        = %s' % self.aliases)
            self._debug_it('sources_packs: year           = %s' % self.year)
            self._debug_it('sources_packs: season_x       = %s' % self.season_x)
            self._debug_it('sources_packs: season_xx      = %s' % self.season_xx)

            links = []
            # &category[10]&query='westworld' + ' ' + 'S01'
            tmp_title = self.original_title + ' S' + self.season_xx
            link = self.ApiBaseLink + quote(ApiCat + '&query=' + tmp_title, safe='/&=')
            links.append(link)
            self._debug_it('sources_packs: original_title=%s  link= %s' % (tmp_title, link))

            threads = []
            append = threads.append

            for link in links:
                append(workers.Thread(self.get_sources_packs, link))
                time.sleep(self.request_delay)

            [i.start() for i in threads]
            [i.join() for i in threads]
            return self.sources

        except Exception as e:
            self._debug_it('sources_packs: Exception %s' % str(e))
            return self.sources

    def get_sources_packs(self, link):
        """
        :param link:
        :return:
        """
        ### https Request 1. Search Page ###
        try:
            results = client.request(link, timeout=self.ReqSearchTimeout)
        except Exception as e:
            self._debug_it('get_sources_packs: Exception https request search item %s' % str(e))
            return None

        if results is None:
            self._debug_it('get_sources_packs: results is None')
            return None

        ji = jackett_indexers()
        rows = ji.process(results)
        if len(rows) == 0:
            return None

        self._debug_it('get_sources_packs: tr parsing done rows=%s' % len(rows))
        self._debug_it('-')

        for row in rows:
            filename = normalize(row.title.replace(':', ''))

            if 'vostfr' in filename or 'vost.en-fr' in filename or 'subfrench' in filename:
                continue

            t = re.split('french|truefrench|multi |vff|vfq|vfi|fre', filename, 1)
            if not t or len(t) < 2:
                self._debug_it('get_sources_packs: French not detected FN= %s'% filename)
                continue

            year_str = re.findall("19\d\d|20\d\d", t[1])
            if year_str:
                tmp_filename = str(t[0]) + str(year_str[0])
            else:
                tmp_filename = str(t[0])

            tmp_filename = re.sub("\(([^\)]+)\)", "", tmp_filename)
            # tmp_filename = re.sub("19\d\d|20\d\d", '', tmp_filename)
            self._debug_it('get_sources_packs: T=%s Original_title=%s ' % (self.title, self.original_title))
            self._debug_it('get_sources_packs: filename=%s' % filename)
            self._debug_it('get_sources_packs: Clean filename=%s' % tmp_filename)
            self._debug_it('get_sources_packs: aliases=%s' % self.aliases)

            episode_start, episode_end, valid = 0, 0, False
            if not self.search_series:
                if not self.bypass_filter:
                    valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases,
                                                                                        self.year, self.season_x,
                                                                                        tmp_filename)
                    self._debug_it('get_sources_packs:1. filter season valid=%s' % str(valid))
                    if not valid:
                        valid, episode_start, episode_end = source_utils.filter_season_pack(self.original_title,
                                                                                            self.aliases, self.year,
                                                                                            self.season_x, tmp_filename)
                        self._debug_it('get_sources_packs:2. filter season valid=%s' % str(valid))
                        if not valid:
                            continue
                package = 'season'

            elif self.search_series:
                if not self.bypass_filter:
                    valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year,
                                                                       self.season_x, tmp_filename, self.total_seasons)
                    self._debug_it('get_sources_packs:1 filter show valid=%s' % str(valid))
                    if not valid:
                        valid, last_season = source_utils.filter_show_pack(self.original_title, self.aliases, self.imdb,
                                                                           self.year, self.season_x, tmp_filename,
                                                                           self.total_seasons)
                        self._debug_it('get_sources_packs:2 filter show valid=%s' % str(valid))
                        if not valid:
                            continue
                else:
                    last_season = self.total_seasons
                package = 'show'

            self._debug_it('get_sources_packs: filter result OK!  T=%s OT=%s FN=%s Y=%s A=%s' % (
            self.title, self.original_title, filename, self.year, self.aliases))

            if not row.magnetUri or 'magnet' not in row.magnetUri:
                continue

            hash40 = row.infoHash

            name_info = source_utils.info_from_name(filename, self.title, self.year, season=self.season_x, pack=package)
            row.quality, row.info = source_utils.get_release_quality(name_info, None)

            seeders = row.seeds
            quality = row.quality
            info = row.info

            if row.size > 1073741824:
                dsize, isize = convert_size(row.size, 'GB')
            elif row.size > 1048576:
                dsize, isize = convert_size(row.size, 'MB')
            elif row.size > 1024:
                dsize, isize = convert_size(row.size, 'KB')
            else:
                dsize, isize = 0, '0'


            if len(hash40) == 32:
                try:
                    hash40 = source_utils.base32_to_hex(hash40, 'get_sources_packs')
                except Exception as e:
                    self._debug_it('get_sources_packs: base32_to_hex %s' % str(e))
                    continue

            self._debug_it('get_sources_packs: parsing done')

            item = {'provider': source.name, 'source': 'torrent', 'seeders': seeders, 'hash': hash40, 'name': filename,
                    'name_info': name_info, 'quality': quality,
                    'language': 'fr', 'url':  row.magnetUri, 'info': info, 'direct': False, 'debridonly': True,
                    'size': dsize,
                    'package': package}

            self._debug_it('APPEND PACKS Provider= %s' % row.tracker)
            self._debug_it('APPEND PACKS filename= %s' % filename)
            self._debug_it('APPEND PACKS quality= %s size= %s' % (quality, isize))
            self._debug_it('APPEND PACKS magnet= %s' %  row.magnetUri)

            if self.search_series:
                item.update({'last_season': last_season})

            elif episode_start:
                item.update({'episode_start': episode_start, 'episode_end': episode_end})  # for partial season packs

            self.sources_append(item)

    def main(self):
        from the_milk.modules.test_modules import Tests
        tests = Tests()
        self.sources(tests.data_movie_4(), '')


if __name__ == "__main__":
    jj = source()
    jj.main()

